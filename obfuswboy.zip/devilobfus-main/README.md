# devilobfus
Lua obfuscator
